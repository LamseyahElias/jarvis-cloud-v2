---
name: business-operations
description: "Business launch ops: API integrations, SaaS stack wiring, deployment, and launch checklists for Elias's businesses."
tags: [business, integrations, api, launch, deployment, belditalk]
---

# Business Operations

Use this skill when onboarding new API keys/services for a business, deploying websites, wiring up SaaS stacks, or preparing launch checklists.

## Trigger Conditions

- User provides API keys/tokens to store
- User asks to set up a new service integration
- User asks what's needed to launch a business/site
- User asks to deploy to Vercel/hosting
- User asks about payment, email, or social media setup

## API Key Onboarding Workflow

1. **Store the key** in `~/.hermes/.env` with a clear comment block:
   ```
   # <Service Name> (<Purpose> - <Business>)
   SERVICE_API_KEY=<value>
   ```
2. **Verify the key works** immediately via API call — don't just store blindly:
   - Meta Graph API: `GET /me?access_token=TOKEN`
   - Meta Page: `GET /me/accounts?access_token=TOKEN` → returns page name, ID, tasks
   - Lemon Squeezy: `GET /v1/users/me` with `Authorization: Bearer TOKEN`
   - Mailchimp: `GET https://<dc>.api.mailchimp.com/3.0/` with basic auth `anystring:API_KEY` (dc = last part of key after `-`)
   - ElevenLabs: `GET /v1/user` with `xi-api-key` header
   - Canva/TikTok: OAuth flow needed, keys alone won't verify
3. **Update the vault registry** at `Business/API Keys & Integrations.md` — add service block with purpose, env var name, status, and use cases. Never put actual keys in the vault.
4. **Update memory** with service status (ready vs needs OAuth vs needs config)

## Verification Endpoints Quick Reference

See `references/api-verification.md` for curl commands per service.
See `references/belditalk-stack.md` for Belditalk-specific services, scripts, deployment, pricing, and Meta posting workflow.
See `references/peace-corps-public-domain.md` for legal status of the Darija ebook source material.

## Launch Checklist (SaaS/Course Business)

Essential stack for an online business like Belditalk:

### Must-Have (blocks launch)
- [ ] Domain name purchased & DNS configured
- [ ] Hosting deployed (Vercel: `vercel login` → `vercel --prod`)
- [ ] SSL certificate (auto with Vercel/Netlify)
- [ ] Payment processor configured with products (Lemon Squeezy / Stripe)
- [ ] Landing page with value proposition + CTA

### Should-Have (launch week)
- [ ] Email capture (Mailchimp signup form embedded)
- [ ] Social media pages connected (Meta Graph API with publish permissions)
- [ ] Analytics (Vercel Analytics or Google Analytics)
- [ ] At least 3-5 content pieces live

### Nice-to-Have (month 1)
- [ ] Email drip campaign for new signups
- [ ] Social media auto-posting via API
- [ ] SEO basics (meta tags, sitemap, robots.txt)
- [ ] Community channel (Discord)

## Meta Business API Notes

- App Token format: `APP_ID|APP_SECRET` — used for app-level calls
- Page Token: long JWT-like string — used for page-level actions
- **Page token exchange (PROVEN):** User tokens stored in .env must be exchanged for page tokens before posting. Call `GET /v21.0/{PAGE_ID}?fields=access_token&access_token={USER_TOKEN}` to get the page token. Do NOT rely on `/me/accounts` — it may return empty `data` even when the token is valid.
- Page ID is NOT the user ID — get it from `/me/accounts` response or from the Facebook page About section
- Permissions must be requested via App Review for production:
  - `pages_manage_posts` — required for auto-posting
  - `instagram_basic` + `instagram_content_publish` — required for IG
  - `pages_read_engagement` — analytics
- Instagram must be linked to FB Page in IG app settings first
- **Token redaction in scripts:** Hermes redacts tokens from output. When using `execute_code`, write tokens to a temp file and read them back rather than passing through stdout.
- **Shell `&` trap:** URLs and data strings containing `&` (like `access_token=X&field=Y`) will be interpreted as shell backgrounding. Use Python `urllib.parse.urlencode()` or curl `-F` multipart flags instead.

## Vercel Deployment

- Install: `sudo npm install -g vercel`
- Login options:
  - Interactive: `vercel login` (needs browser)
  - Token: get from vercel.com/account/tokens, use `--token=<TOKEN>` flag
- Deploy: `cd /path/to/project && vercel deploy --prod --yes --token=<TOKEN>`
- Token deploy: pass `--token=` with `=` (not space) — `--token <val>` throws ARG_MISSING_REQUIRED_LONGARG
- Custom domain: `vercel domains add example.com`
- Env vars: `vercel env add SECRET_NAME`
- The `name` property in vercel.json is deprecated — Vercel warns but deploys fine

## Lemon Squeezy API Quirks

- **Products AND Variants APIs are READ-ONLY.** PATCH/POST to `/v1/products/{id}` or `/v1/variants/{id}` returns 405 Method Not Allowed. Products and prices MUST be managed in the dashboard at app.lemonsqueezy.com. Use GET to retrieve IDs afterward. Tell the user immediately when price changes are needed — don't waste time trying the API.
- **Discounts CAN be created via API.** POST `/v1/discounts` works. JSON:API format with store relationship.
- **Files API is also READ-ONLY.** POST to `/v1/files` returns 405. Digital product files (ebooks, PDFs) must be uploaded in the dashboard under each product. Inform the user immediately.
- **URL brackets must be percent-encoded.** `filter[store_id]` causes curl "bad range" error. Use `filter%5Bstore_id%5D=<id>` instead.
- **All requests need both headers:** `Accept: application/vnd.api+json` and `Authorization: Bearer <key>`.
- **Checkout overlay:** Add `<script src="https://assets.lemonsqueezy.com/lemon.js" defer></script>` and use `class="lemonsqueezy-button"` on buy links for in-page checkout.
- **Prices in API are in cents.** MAD 290.00 = 29000 in the API. MAD 49.00 = 4900.

## Mailchimp Integration Details

- **Signup form action URL format:** `https://gmail.<dc>.list-manage.com/subscribe/post?u=<uid>&id=<list_id>`

## Social Media Image Generation (Pillow)

When automated branded image generation is needed (daily posts, marketing graphics), use Python Pillow — NOT Canva API (requires interactive OAuth, impractical for headless automation).

**Working pipeline:**
1. Script: `~/.hermes/scripts/belditalk_image_gen.py`
2. Generates 1080x1080 branded PNGs with 6 templates (word, culture, lesson, phrase, promo, quiz)
3. Uses DejaVu Sans fonts (system-installed, supports Latin + Arabic)
4. CLI: `python3 belditalk_image_gen.py --type word --text "Zwin" --subtitle "Beautiful|zwee-n|Example" --output post.png`
5. Daily auto: `python3 belditalk_image_gen.py --generate-daily --output-dir ./posts/`
6. Samples: `python3 belditalk_image_gen.py --generate-samples --output-dir ./samples/`

**For better Arabic typography:** `apt install fonts-arabeyes` or download Google Fonts Cairo/Amiri.

## PDF Ebook Pipeline (ReportLab + PyPDF2)

To create branded ebooks from public domain content:
1. Generate cover/attribution pages with ReportLab (canvas API, programmatic PDF creation)
2. Merge with source PDF using PyPDF2 PdfWriter
3. Set metadata: `/Title`, `/Author`, `/Subject`, `/Creator`
4. Script: `~/belditalk-ebook/build_ebook.py`
5. Install: `pip install reportlab PyPDF2 pikepdf`

## Mailchimp Additional Details
- **Honeypot field** (required for bot prevention): `<input type="text" name="b_<uid>_<list_id>" tabindex="-1" value="" style="position:absolute;left:-5000px">`
- **Tags via API:** POST `/lists/{list_id}/segments` with `{name, static_segment: []}` to create tags.
- **AJAX submission:** Use `fetch()` to the form action URL to avoid page redirect. Show success/error inline.

## Pitfalls

1. **Always verify keys immediately.** A stored-but-broken key wastes future debugging time.
2. **Pipe character in .env values breaks `source`.** Tokens like `APP_ID|SECRET` must be quoted: `META_APP_TOKEN='123|abc'`. Otherwise bash interprets `|` as a pipe operator. Use `sed` to wrap in quotes if needed.
3. **Mailchimp datacenter matters.** The `-usXX` suffix on the API key determines the API subdomain. Wrong dc = 401.
4. **Meta Page Token vs User Token.** The token from `/me/accounts` is the real page token with page-scoped permissions. The initial user token may lack page permissions.
5. **Lemon Squeezy JWT expiry.** Check the `exp` claim — keys expire. Current key expires ~2027-01.
6. **npm global install on WSL needs sudo.** `npm install -g` without sudo fails with EACCES.
7. **Vault tracks WHAT, not secrets.** The Obsidian note records service name, env var, status, use cases. Actual keys stay in .env only.
8. **Lemon Squeezy product, price, AND file management is dashboard-only.** Products, variants, prices, and file uploads cannot be created or updated via API (405 on POST/PATCH). Inform the user immediately to make changes in the dashboard.
9. **Canva API requires OAuth2 authorization_code flow** — impractical for headless/automated use. Use Python Pillow instead for automated branded image generation (social media posts, banners). Script at `~/.hermes/scripts/belditalk_image_gen.py` generates 1080x1080 branded images with 6 templates (word, culture, lesson, phrase, promo, quiz).
10. **Claude Code `--max-turns 30` may not be enough for large HTML rebuilds.** A 3000-line single-file website rebuild hit the 30-turn limit. Use 40-50 for big rewrites, or split the prompt into sequential runs with `--continue`.
11. **Meta page "tasks" ≠ API permissions.** A page token from `/me/accounts` may show tasks like ADVERTISE, CREATE_CONTENT, MANAGE — but this does NOT mean the API-level permissions (like `pages_manage_posts`) are granted. Tasks are page-role permissions; API permissions must be requested separately in the Meta App Dashboard under App Review. Always check `/me/permissions` to verify actual API access before attempting to post.
12. **Vercel `--token` syntax.** Use `--token "$VERCEL_TOKEN"` (with quotes). The `--token=VALUE` form and `--token VALUE` both work, but if the env var is empty, `--token` alone throws "missing a value". Always `source ~/.hermes/.env` first to ensure the var is loaded.
13. **Vercel `--yes` flag for CI.** Include `--yes` to skip interactive project setup prompts. Without it, Vercel asks for project linking confirmation.
14. **Full business audit before launch.** When the user asks "can you handle this," do a systematic readiness check: website live + returning 200, checkout links returning 302 (redirect to checkout), e-book PDF exists and has correct page count, email list has subscribers, API permissions actually work (not just stored). Don't rely on stored status — verify live.
15. **GitHub as Vercel source.** When `vercel login` fails (expired token, no browser), push to GitHub and use `vercel --prod --yes --token` from a linked project. The `.vercel/project.json` file preserves the project link. Create the repo with `gh repo create` if it doesn't exist.
