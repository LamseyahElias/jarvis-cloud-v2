# Belditalk SaaS Stack Reference

## Project Location
Website: `/mnt/c/Users/USER/belditalk.com/`
- `public/index.html` — single-file website (~3920 lines, all CSS/JS inline)
- `public/images/logo-new.svg` — current SVG logo (Moroccan speech bubble + zellige + star)
- `public/images/favicon.svg` — icon-only favicon
- `public/images/logo-nobg.png` — OLD logo (no longer used in HTML)
- `content/beginner-course/module-01..12.md` — 12 Darija lesson modules (~100KB total)
- `scripts/meta_poster.py` — Facebook page auto-posting CLI
- `scripts/mailchimp_manager.py` — subscriber management CLI
- `scripts/launch-checklist.md` — full pre-launch checklist
- `scripts/email-sequences.md` — 5-email welcome drip sequence
- `scripts/social-media-calendar.md` — 30-day content calendar
- `scripts/seo-keywords.md` — keyword research + content map
- `scripts/discord-structure.md` — Discord server setup plan
- `vercel.json` — deployment config (static site routing)
- `CLAUDE.md` — full spec for Claude Code rebuilds (13KB, very detailed)

E-book source: `/mnt/e/Belditalk.com/the book without cover/Moroccan Arabic textbook 2011_240714_085731.pdf` (197 pages, 14MB, Peace Corps public domain)
Branded ebook: `~/belditalk-ebook/I_Love_Moroccan_Darija_BeldiTalk.pdf` (198 pages, 13.7MB — cover + attribution + content)
Starter pack PDF: `~/belditalk-ebook/BeldiTalk_Starter_Pack_20_Phrases.pdf` (4 pages, 5KB)
Ebook build script: `~/belditalk-ebook/build_ebook.py` (ReportLab cover + PyPDF2 merge)
Business docs: `/mnt/e/Belditalk.com/` (Business plan, Strategy, Brainstorm, Teaching Program, Edits PDFs)

## Source Control
- **GitHub:** https://github.com/LamseyahElias/belditalk (created May 2026)
- **Branch:** main
- **Remote:** origin

## Live Deployment
- **URL:** https://belditalk.vercel.app
- **Vercel project:** belditalk (prj_AC3ae7cZ9cxPQXcdKTzGvvACidhr, org: team_Mm7ccqjjPQHaRRWrGLrBekjD)
- **Deploy command:** `source ~/.hermes/.env && cd /mnt/c/Users/USER/belditalk.com && vercel --prod --yes --token "$VERCEL_TOKEN"`

## Website Features (as of May 2026 rebuild)
- Darija quiz (5 questions, score tracking, share button)
- Dark mode toggle (localStorage persisted)
- Animated number counters (scroll-triggered)
- Page progress indicator widget
- Cookie consent banner
- Blog/resources section with expandable articles (no dead links)
- Analytics: localStorage tracking of page_views, section_views, button_clicks, quiz_completions
- Hidden admin panel: Ctrl+Shift+A (view stats, export JSON)
- JSON-LD structured data (Product schema)
- Favicon (SVG)
- All Lemon Squeezy checkout links use overlay checkout (lemon.js)
- 3 Mailchimp signup forms (AJAX/JSONP submission)

## Active Services
| Service | Status | Env Var | Notes |
|---------|--------|---------|-------|
| Meta Business | ✅ Posting works | META_PAGE_TOKEN, META_PAGE_ACCESS_TOKEN | Page: BeldiTalk (ID: 1047439671795847). `pages_manage_posts` GRANTED. Must exchange user token → page token (see workflow below) |
| Lemon Squeezy | ✅ Products live | LEMON_SQUEEZY_API_KEY | Store: 385319. Products: Starter (MAD 50), Beginner (MAD 290), Premium (MAD 490). Discount WELCOME20 (ID: 1027844, 20% off). Files NOT yet uploaded — must be done in dashboard |
| Mailchimp | ✅ Ready | MAILCHIMP_API_KEY | List: 7317b7b5dd, dc: us10, email: belditalk212@gmail.com. Tags: website-signup, free-starter, beginner-course, premium-bundle |
| ElevenLabs | ✅ Ready | ELEVENLABS_API_KEY | TTS for pronunciation audio |
| Vercel | ✅ Deployed | VERCEL_TOKEN | CLI v54.4.1, deployed to https://belditalk.vercel.app |
| Canva | ❌ Impractical | CANVA_CLIENT_ID/SECRET | Requires OAuth2 authorization_code flow — not viable for headless automation. Use Pillow instead. |
| TikTok | ⚠️ Needs OAuth | TIKTOK_CLIENT_KEY/SECRET | For content publishing |

## Pricing (Updated May 24 2026)
- **Starter Pack:** MAD 50 (one-time, 20 phrases PDF + pronunciation guide + cultural tips)
- **Beginner Course:** MAD 290 (one-time, lifetime access, 197-page ebook + 12 modules)
- **Premium Bundle:** MAD 490 (one-time, includes live Zoom sessions + all future courses)
- **Discount:** WELCOME20 for 20% off

## Lemon Squeezy Checkout URLs
- **Starter Pack (MAD 50):** https://belditalk.lemonsqueezy.com/checkout/buy/e2395ee0-7003-4747-8dd2-44b782541421
- **Beginner Darija Course (MAD 290):** https://belditalk.lemonsqueezy.com/checkout/buy/476e9db3-3cd2-4c17-bc67-251371f837e4
- **Premium Darija Bundle (MAD 490):** https://belditalk.lemonsqueezy.com/checkout/buy/b59fcba6-098e-426d-8663-c62e3e5cc34f

## Meta Posting Workflow (PROVEN)

The META_PAGE_TOKEN in .env is a **user access token**. To post to the page, you must exchange it for a **page access token** first.

```
Step 1: Exchange user token → page token
GET https://graph.facebook.com/v21.0/1047439671795847?fields=access_token&access_token=$META_PAGE_TOKEN

Step 2: Use the returned page token to post
POST https://graph.facebook.com/v21.0/1047439671795847/feed
  message=<text>
  access_token=<page_token_from_step_1>
```

**IMPORTANT:** The `/me/accounts` endpoint may return empty data even when the token is valid. Always request `access_token` directly from the page ID instead.

**IMPORTANT:** When posting via execute_code or scripts, the system redacts tokens in output. Write tokens to a temp file (`/tmp/page_tok.txt`) and read them back to avoid redaction breaking the token value.

**IMPORTANT:** Shell commands with `access_token=<token>` containing `&` will be interpreted as shell backgrounding. Use Python `urllib` or `-F` curl flags instead of `--data-urlencode` with `&` in the data string.

## Image Posts (with photo)

To post with an image, use multipart/form-data to the `/photos` endpoint:
```
POST https://graph.facebook.com/v21.0/1047439671795847/photos
  source=@/path/to/image.png (binary)
  message=<text>
  access_token=<page_token>
```

Use Python urllib with multipart boundary construction (see belditalk_daily_post.py for working implementation).

## Daily Posting Automation
- **Script:** `~/.hermes/scripts/belditalk_daily_post.py` (v2 — generates images + text)
- **Image gen:** `~/.hermes/scripts/belditalk_image_gen.py` (Pillow-based, 6 templates, 1080x1080)
- **Cron job:** `BeldiTalk Daily Facebook Post` (job ID: d12d2031f8f7) — runs daily at 10:00 AM
- **Content rotation:** 7 post types (word of the day, cultural tip, mini lesson, phrase, promo, quiz, greetings)
- The script handles the user→page token exchange automatically
- Image generation uses Pillow with DejaVu Sans fonts and brand colors

## Ebook Status

**Legal:** The source PDF is a Peace Corps Morocco training manual (2011). Under 17 USC § 105, US government works are public domain — no copyright restrictions, including commercial use. Only requirement: do NOT use Peace Corps name/logo in a way suggesting endorsement (trademark, not copyright).

**Current state:** Branded version created with BeldiTalk cover page + attribution page, original acknowledgements page removed. Needs upload to Lemon Squeezy dashboard for auto-delivery to customers after purchase.

**Files ready for upload:**
- Starter product → `~/belditalk-ebook/BeldiTalk_Starter_Pack_20_Phrases.pdf`
- Beginner/Premium product → `~/belditalk-ebook/I_Love_Moroccan_Darija_BeldiTalk.pdf`

## Website CLAUDE.md Rebuild Pattern
When the site needs a full rebuild:
1. Update `CLAUDE.md` with the new spec
2. `git add -A && git commit -m "Pre-build spec update"`
3. `claude -p "Read CLAUDE.md carefully. Build the ENTIRE website..." --allowedTools "Read,Write,Edit,Bash" --max-turns 50`
   **Note:** Use 40-50 max-turns for large rebuilds. 30 turns was insufficient for a full 3000+ line HTML overhaul.
4. Verify: `wc -l public/index.html` (should be 3000+)
5. Check integrations: grep for mailchimp form URL, lemon.js, checkout URLs, quiz section, dark-mode, analytics
6. Test: `python3 -m http.server 3001 --directory public` → http://localhost:3001
7. `git add -A && git commit -m "Full website build"`
8. Deploy: `source ~/.hermes/.env && vercel --prod --yes --token "$VERCEL_TOKEN"`

## Remaining Blockers
1. ~~Meta `pages_manage_posts` permission~~ ✅ RESOLVED May 2026
2. Domain DNS → register belditalk.com and point to Vercel
3. Discord community server — not set up yet
4. **E-book files need upload to Lemon Squeezy dashboard** (API doesn't support file upload)
5. Mailchimp welcome automation — email sequence written but not loaded into Mailchimp automation builder
6. Thank-you URLs not set on Lemon Squeezy products (dashboard setting)
