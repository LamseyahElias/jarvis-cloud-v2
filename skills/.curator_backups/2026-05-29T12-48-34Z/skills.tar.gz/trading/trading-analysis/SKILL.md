---
name: trading-analysis
description: "XAUUSD (gold) technical analysis, MetaTrader 5 integration, smart trade execution with AMD strategy. Open, manage, and close trades profitably."
version: 3.0.0
author: JARVIS
platforms: [linux]
metadata:
  hermes:
    tags: [trading, xauusd, mt5, smc, amd, execution]
---

# Hermes Trading Engine — Smart Execution

> JARVIS is a nickname for Hermes Agent — they are the same system, not separate entities.

## Core Rule: STACK SMALL WINS

Quick scalp philosophy: $5 profit target, multiple trades per day. 10 wins × $5 = $50.
1. **$5 target — close and move on.** Don't wait for more.
2. **$3+ profit → lock $1** (SL to entry ± $1). Below $3: hands off.
3. **Never let a winning trade turn into a losing trade**
4. **Max 10 trades/day.** Quality over quantity.
5. **15-min cooldown after loss.** No revenge trading.

## Trade Management Protocol

### ACCOUNT SIZE MATTERS — Scale Parameters to Balance

**Small accounts ($50-100):** Quick scalp mode — $5 targets.
- SL: $5 max ($5 risk on 0.01 lot)
- TP: $5 (1:1 R:R — high win rate compensates)
- Auto-close at +$5 profit via Position Manager
- Lock $1 profit at +$3 (SL to entry ± $1)
- Peak drawdown: if $3+ drops to $0.50, close immediately
- Lot size: 0.01 (< $80 balance) or 0.02 ($80+)
- Max 10 trades/day, 1 position at a time

**Medium accounts ($100-500):** Standard pip-based management.
- SL/TP: 15/20 pips, lot 0.02-0.05

**Large accounts ($500+):** Full system with wider stops.

### Phase 1: Entry
- Only enter on AMD-confirmed setups (see Entry Criteria below)
- Calculate lot size: `lot = (balance × risk_pct) / (sl_pips × pip_value)`
- For XAUUSD: pip_value ≈ $1.00 per 0.01 lot per pip
- Max lot = balance × 0.8 / (sl_pips × pip_value_per_lot), capped at 0.50

### Phase 2: Active Management (CRITICAL — check every 1 MINUTE)
Once a trade is open, manage it in stages.

**⚠️ THE $11 LESSON:** A trade reached +$11 profit but wasn't closed because cron was too slow and BE was placed too early. User was furious. Don't let profits evaporate.

**⚠️ THE BE LESSON (USER CORRECTION):** User explicitly said "BREAK EVEN SHOULD BE PLACED WITH A HIGHER PROFIT". Moving SL to BE at +$3 suffocates trades — gold needs room to breathe. NO SL MOVEMENT until +$5 profit. Let the trade work.

**Small Account Stages ($50-100) — v4 Quick Scalp (current):**

**$0 to $3 — DO NOTHING. Let it breathe.**
- Original SL stays. Don't touch it.
- Gold is volatile, small profits can grow fast if you don't choke them.

**Stage 1 — Lock $1 (+$3 profit):**
- Move SL to lock $1 profit (entry ± $1/profit_per_point)
- This is the FIRST and ONLY SL move before close.

**Stage 2 — TAKE PROFIT (+$5):**
- CLOSE THE TRADE. $5 scalp complete.
- Don't wait for more. Stack the next trade.

**Peak Drawdown Protection:**
- If peak profit was $3+ and current drops to $0.50 → CLOSE (save something)
- Don't let winners evaporate. The $11 lesson: take profits when they're there.

**Standard Account Stages ($100+):**

**Stage 1 — Protect (0-10 pips profit):**
- Monitor every 2 minutes
- If price reverses 5+ pips from peak, tighten SL to -5 pips (reduce risk)

**Stage 2 — Break Even (10+ pips profit):**
- Move SL to entry price (break even)

**Stage 3 — Lock Profit (15+ pips profit):**
- Move SL to entry + 10 pips (lock $10/pip × lots)
- Let TP at +20 pips hit naturally

**Stage 4 — Extended Run (20+ pips, TP hit or trailing):**
- If momentum is strong, trail SL 10 pips behind price
- Let winners run when distribution phase is active
- Close manually if momentum fades (volume drops, wicks appear)

### Phase 3: Exit Rules
- **TP hit:** Log profit, update challenge tracker
- **SL hit at BE:** No loss, find next setup
- **SL hit at loss:** Log it, check if loss ≤ previous win
- **Manual close:** Only if reversal signals appear (CHoCH, engulfing, volume spike against position)

## Entry Criteria (AMD Filter)

Only trade when ALL conditions are met:

### BUY Setup:
1. ✅ Price swept below a liquidity pool (stop hunt / manipulation)
2. ✅ Bullish CHoCH or BOS on 15m timeframe
3. ✅ Entry at bullish OB or FVG after the sweep
4. ✅ RSI(15m) < 60 (not overbought)
5. ✅ EMA9 crossing above EMA21 (or price reclaiming EMAs)
6. ✅ London or NY session active
7. ✅ Not within 30min of high-impact news

### SELL Setup:
1. ✅ Price swept above a liquidity pool (stop hunt / manipulation)
2. ✅ Bearish CHoCH or BOS on 15m timeframe
3. ✅ Entry at bearish OB or FVG after the sweep
4. ✅ RSI(15m) > 40 (not oversold)
5. ✅ EMA9 crossing below EMA21 (or price losing EMAs)
6. ✅ London or NY session active
7. ✅ Not within 30min of high-impact news

## Confluence Scoring

Score each setup 0-7 based on criteria above. Only trade 4+ score:
- **7/7:** Full send — max risk (80% of balance for challenge)
- **6/7:** Strong — 60% risk
- **5/7:** Good — 40% risk
- **4/7:** Acceptable — 20% risk (conservative lot)
- **3/7 or below:** NO TRADE — wait

Note: Original threshold was 5/7 but in practice a 7/7 setup existed and the scalper didn't fire due to a separate bug. Lowered to 4/7 to avoid missing high-confluence trades. The score system catches most noise — 4 is still 4 independent confirmations.

## Smart Close Logic

```python
def should_close(position, current_price, entry_price, direction):
    pips_profit = (current_price - entry_price) if direction == 'BUY' else (entry_price - current_price)
    pips_in_pips = pips_profit / 0.01  # XAUUSD pip = $0.01

    # Close signals:
    # 1. TP hit (20 pips)
    if pips_in_pips >= 20:
        return True, "TP_HIT"
    # 2. Strong reversal candle against position
    # 3. CHoCH against position direction
    # 4. Volume spike with price moving against us
    # 5. RSI extreme (>75 for BUY, <25 for SELL)
    return False, "HOLD"
```

## SL Trailing Logic

```python
def get_trailing_sl(direction, entry, current_price, current_sl):
    if direction == 'BUY':
        profit_pips = (current_price - entry) * 100
        if profit_pips >= 15:
            new_sl = entry + 10 * 0.01  # lock 10 pips
        elif profit_pips >= 10:
            new_sl = entry  # break even
        elif profit_pips >= 5:
            new_sl = entry - 5 * 0.01  # reduce risk
        else:
            return current_sl
        return max(new_sl, current_sl)  # never move SL backwards
    else:  # SELL
        profit_pips = (entry - current_price) * 100
        if profit_pips >= 15:
            new_sl = entry - 10 * 0.01
        elif profit_pips >= 10:
            new_sl = entry
        elif profit_pips >= 5:
            new_sl = entry + 5 * 0.01
        else:
            return current_sl
        return min(new_sl, current_sl)
```

## Session Windows (UTC)

- **Asian** 00:00-08:00 — Accumulation (tight range, set up levels)
- **London** 07:00-16:00 — Manipulation (fake breakouts, stop hunts)
- **New York** 13:00-22:00 — Distribution (real move, ride it)
- **London/NY Overlap** 13:00-16:00 — BEST window (highest volume)

## Execution Commands

Scripts: `~/trading/scripts/` | Cron copies: `~/.hermes/scripts/`

```bash
# Quick analysis
cd ~/trading/scripts && python3 xauusd_analyzer.py --brief

# Full report
cd ~/trading/scripts && python3 xauusd_analyzer.py
```

### Open/Close via MT5Bridge (preferred — avoids TradeExecutor bugs):
```python
from mt5_bridge import MT5Bridge
mt5 = MT5Bridge()
mt5.connect()
mt5.initialize()  # MANDATORY

# Get tick FIRST (before any other calls — rpyc stability)
tick = mt5.symbol_info_tick('XAUUSD')
acc = mt5.account_info()
positions = mt5.positions_get()

# Open trade
result = mt5.order_send({
    'action': 1, 'symbol': 'XAUUSD', 'volume': 0.01,
    'type': 1,  # 0=BUY, 1=SELL
    'price': tick.bid,  # bid for SELL, ask for BUY
    'sl': round(tick.bid + 7, 2), 'tp': round(tick.bid - 10, 2),
    'deviation': 20, 'magic': 123456,    'comment': 'HERMES_S7',
    'type_time': 0, 'type_filling': 1,
})
# retcode 10009 = success

# Close trade (MUST include sl=0.0, tp=0.0)
result = mt5.order_send({
    'action': 1, 'symbol': 'XAUUSD', 'volume': 0.01,
    'type': 0,  # opposite of open direction
    'position': ticket_number,
    'price': tick.ask,  # ask for closing SELL
    'sl': 0.0, 'tp': 0.0,
    'deviation': 20, 'magic': 123456,    'comment': 'HERMES_CLOSE',
    'type_time': 0, 'type_filling': 1,
})

mt5.shutdown()
mt5.disconnect()
```

### TradeExecutor (legacy — has rpyc bugs, use for analysis only):
```python
from trade_executor import TradeExecutor
ex = TradeExecutor()
ex.connect()
acc = ex.get_account_info()
# WARNING: get_tick() can return None after get_open_positions() — rpyc bug
ex.disconnect()
```

## Risk Rules — Hard Limits

- Max risk per trade: 80% (challenge) / 1% (normal)
- Max daily loss: 3% → stop trading for the day
- Max open positions: 1 (challenge) / 3 (normal)
- Max lot: 0.50
- Never revenge trade — wait 15min after SL hit
- Never trade during high-impact news (within 30min)
- $60 balance with 1:500 leverage → safe max ~0.03 lots

## MT5 Bridge Notes

- RPyC server: `C:\Users\USER\mt5_rpyc_server.py` (Windows)
- WSL connects: `172.26.128.1:18812`
- Server returns plain dicts (not MT5 objects) — avoids pickle errors
- `order_send` → `exposed_send_order` with keyword args
- `positions_get` → `exposed_get_positions` returning list of dicts
- Close orders need `sl=0.0, tp=0.0` in the request
- Start server: `powershell.exe -Command "Start-Process -FilePath 'python' -ArgumentList 'C:\Users\USER\mt5_rpyc_server.py' -WorkingDirectory 'C:\Users\USER'"`

### Direct RPyC Access (preferred for quick checks & boot)

The server exposes `exposed_mt5 = mt5` as a class attribute. Access MT5 module methods via `c.root.mt5.<method>()`, NOT `c.root.<method>()`:

```python
import rpyc
c = rpyc.connect('172.26.128.1', 18812)
svc = c.root          # the MT5Service instance
mt5 = svc.mt5         # the MetaTrader5 module (exposed_mt5)

mt5.initialize()      # double-init for stability
mt5.initialize()

info = mt5.account_info()
tick = mt5.symbol_info_tick('XAUUSD')

# Use the exposed helpers for serialization-safe results:
positions = svc.get_positions()   # returns list of plain dicts
# svc.send_order(action, symbol, volume, ...) for orders

c.close()
```

Common mistake: `c.root.initialize()` → `AttributeError: 'MT5Service' has no attribute 'initialize'`. It's `c.root.mt5.initialize()`.

## Challenge Tracker

Obsidian vault: `/mnt/e/New folder (2)/Son/Challenge/20 Pip Challenge.md`
Trade logs: `/mnt/e/New folder (2)/Son/Trades/`
After each trade, update the trade log table, daily log, and status section.

## Support Files

- `references/rpyc-bridge-architecture.md` — RPyC server/client architecture details and version quirks
- `references/position-management-rules.md` — Trailing SL stages, daily loss limits, the "$15 unmanaged" and "$11 evaporated profit" lessons
- `references/auto-trading-architecture.md` — Auto-scalper + position manager v2 architecture, score criteria, bugs found, state files
- `references/agentic-os-boot.md` — Agentic OS v2 architecture (modular Streamlit app), identity clarification (JARVIS=Hermes nickname), boot sequence, dual chat integration, Obsidian sync, pitfalls
- `templates/mt5_rpyc_server.py` — Windows-side RPyC server template (v3, returns plain dicts)

## Pitfalls

1. **RPyC pickle errors:** MT5 returns custom types (OrderSendResult, TradePosition) that can't be pickled over RPyC v6. ALL results must be converted to plain dicts on the Windows server side. Never try `rpyc.utils.classic.obtain()` on MT5 result objects — it will fail with "Can't pickle <class 'OrderSendResult'>".
2. **RPyC v6 exposed methods:** RPyC v6 changed how exposed methods work. Class attributes like `exposed_mt5 = mt5` work for module access. For custom methods, define them as `exposed_<name>()` and call as `conn.root.exposed_<name>()`.
3. **RPyC version mismatch:** Windows and WSL must run the same major RPyC version. mt5linux pins rpyc==5.2.3 but we need rpyc>=6.0 to match Windows. Install with `--force` and ignore the mt5linux compatibility warning.
4. **WSL→Windows networking:** `localhost` does NOT route to Windows from WSL. Use the gateway IP from `ip route show default | awk '{print $3}'` (typically 172.26.x.1). The DNS nameserver in /etc/resolv.conf is a different IP and may not work.
5. **order_send needs all fields:** Close orders MUST include `sl=0.0, tp=0.0` — omitting them causes "Invalid sl argument" error. The server-side wrapper handles this but direct calls will fail.
6. **Position ticket confusion:** `positions_get()` can return multiple positions. Always match by ticket number. During testing, a "successful close" actually closed a DIFFERENT position — verify ticket matches before and after close.
7. **Lot too big:** $60 @ 1:500 leverage → margin per lot = price×100/leverage = ~$906/lot for XAUUSD at $4530. Safe max ~0.03 lots. 0.02 is conservative.
8. **Market closed:** Fri 22:00 - Sun 22:00 UTC — no trading
9. **Spread widens:** During news or low-liquidity, spread can jump to 30-50 pips on gold
10. **Slippage:** Always set deviation=20 for gold
11. **yfinance vs MT5:** GC=F (futures) vs XAUUSD (spot) — prices differ $5-15. yfinance data is delayed.
12. **yfinance timeout:** When MT5 server is down, the MT5 connection attempt can block for 30+ seconds. Set `socket.setdefaulttimeout(5)` in data_provider.py before attempting MT5 connection.
13. **Never leave positions unmanaged:** ALWAYS have the position_manager cron running (**every 2min**) when trades are open. A test trade left unmanaged lost $15 in <30 minutes. A managed trade lost $8 of profit ($11 → $3) because the cron was too slow at 5min.
14. **RPyC server auto-launch from WSL:** `powershell.exe -Command "Start-Process python -ArgumentList 'C:\Users\USER\mt5_rpyc_server.py' -WindowStyle Minimized"` — cmd.exe hangs, PowerShell Start-Process works.
15. **MT5Bridge.initialize() is MANDATORY:** After `mt5.connect()`, you MUST call `mt5.initialize()` before any data calls. Without it, `positions_get()`, `symbol_info_tick()`, `account_info()` all return None. TradeExecutor.connect() handles this, but raw MT5Bridge scripts (like position_manager.py) must call it explicitly.
16. **exposed_get_positions can corrupt RPyC state:** Calling `conn.root.exposed_get_positions()` sometimes makes subsequent `symbol_info_tick()` return None (intermittent). Workaround: use `mt5.positions_get()` directly via the bridge instead of the server-side wrapper, or re-initialize after exposed calls. Position manager v2 uses direct bridge calls to avoid this.
17. **Close orders via direct MT5Bridge (not TradeExecutor):** For reliable closes from cron scripts, use MT5Bridge directly with `order_send()`. Include `sl=0.0, tp=0.0` in close requests. The TradeExecutor wrapper adds overhead and its `get_tick()` can fail after `get_open_positions()` (see #16).
18. **Small account lot sizing:** On $55 account, 0.02 lot with $15 SL = $30 risk (55% of account!). Use 0.01 lot with $7 SL = $7 risk (13%). Never risk more than 15% per trade on sub-$100 accounts.
19. **Auto-scalper silence debugging:** When auto_scalper.py produces no output and no trade, add debug mode. The score might be high enough but tick data failed silently. Always test the full pipeline manually before trusting cron: connect → get positions → get tick → score → prepare → execute.
20. **Double mt5.initialize() for IPC stability:** Cron scripts running every 1-2 min can hit stale IPC connections. Calling `mt5.initialize()` twice before any data calls fixes this. The get_mt5() helper in auto_scalper v4 implements this pattern.
21. **Hermes venv needs trading deps:** Cron scripts run under Hermes's own Python venv (~/.hermes/hermes-agent/venv/). rpyc, yfinance, pandas, ta, numpy, python-dotenv must be installed there: `~/.hermes/hermes-agent/venv/bin/python3 -m pip install rpyc yfinance pandas ta numpy python-dotenv`
22. **Quick scalp TP management:** Don't set MT5 TP too close to current price (causes "Invalid stops"). Set TP wide on MT5 side and let Position Manager handle the $5 auto-close. PM checks every 1 minute.
23. **Cron job spam when not trading:** The 4 trading cron jobs (Auto Scalper every 2m, Position Manager every 1m, Market Monitor every 30m, Daily Report 7am) fire constantly when enabled. `no_agent: true` jobs send stdout verbatim — even "no positions" or "no signal" output gets delivered. **ALWAYS pause all cron jobs when not actively trading.** Only resume on explicit user command. The user is fed up with random messages — this is non-negotiable. Pause with `cronjob(action='pause', job_id=...)` for each job. Also: the `deliver: origin` setting sends output to the chat/channel that created the job, which can be the CLI session — confusing if the user moved to Telegram.
